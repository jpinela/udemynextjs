import Image from 'next/image';
import classes from './hero.module.css';

function Hero(){
    return(
        <section className={classes.hero}>
            <div className={classes.image}>
                <Image src="/images/site/helena.jpg" alt="an image showing helena" 
                    width={300} height={300}/></div>
            <h1>hi ,I'm Helena</h1>
            <p>
                I blog about this and that , here and there
            </p>
            
        </section>

    );

}

export default Hero;