import classes from './logo.module.css';

function Logo(){
    return (
        <div className={classes.logo}>Helena's Cathlic Blog</div>
    );
}

export default Logo;