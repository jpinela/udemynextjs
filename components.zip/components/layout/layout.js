

import { Fragment } from "react";

import MainNavigation from './main-navigation';

function MyLayout(props){
    return(
      <Fragment>
        <MainNavigation/>
        <main>{props.children}</main>
      </Fragment>  
    );
}

export default MyLayout;